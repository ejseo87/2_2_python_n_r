# 주석달기 test
a <- 5     # a에 5를 입력
print(a) # a 값을 인쇄

