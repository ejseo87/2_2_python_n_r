# test1.r
a <- 10
b <- 5
print(a %/% b)

