# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 19:52:55 2019

@author: root
"""

a = 100
print(type(a))
b = 100.1
print(type(b))

print(bool(23.7))
print(bool(0))
print(bool(''))

c = 'my string'
d = str(a)+" "+c
print(d)
print(int(b))
