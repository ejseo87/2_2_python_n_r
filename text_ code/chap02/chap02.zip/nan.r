height <- c(45, 75, 60, 51, NA)
mean(height)
mean(height, na.rm=T)
x <- c(1, -1, 0, Inf, -Inf)
x/0
x/Inf 
