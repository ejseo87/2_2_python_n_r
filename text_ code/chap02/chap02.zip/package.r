install.packages("ggplot2")
library(ggplot2)
qplot(wt, mpg, data=mtcars)
