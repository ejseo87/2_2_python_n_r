# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 11:53:51 2019

@author: Sim
"""

# 주석달기 test
a = 5     # a에 5를 입력
print(a) # a 값을 인쇄