# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 11:06:26 2019

@author: Sim
"""
import numpy as np

a = np.arange(15)
print(a)

m = np.mean(a)
print(m)